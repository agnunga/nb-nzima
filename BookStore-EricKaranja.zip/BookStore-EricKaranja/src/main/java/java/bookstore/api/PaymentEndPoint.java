/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.api;

import java.bookstore.beans.PaymentBean;
import java.bookstore.custommessage.CustomeResponseMessage;
import java.bookstore.models.Payment;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 *
 * @author karanjaeric
 */
//Payment resource
@Path("/payment")
public class PaymentEndPoint {
    @EJB
    PaymentBean paymentBean;
    
  //Endpoint method for making a payment
    @Path("/makepayment")
    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
   public CustomeResponseMessage makePayment(Payment payment){
        CustomeResponseMessage response=new CustomeResponseMessage();
        if(paymentBean.makePayment(payment)){
            response.setData(payment.toString());
            response.setStatus("payment made successfully");
            return response;
           
        
        }
        else{
            response.setData(payment.toString());
            response.setStatus("errors were encountered when making the payment");
            return response;
        
        }
        
    
    }
   
   //Endpoint method for updating a payment
    @Path("/updatepayment")
    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
   public CustomeResponseMessage updatePayment(Payment payment){
        CustomeResponseMessage response=new CustomeResponseMessage();
        if(paymentBean.makePayment(payment)){
            response.setData(payment.toString());
            response.setStatus("payment updated successfully");
            return response;
           
        
        }
        else{
            response.setData(payment.toString());
            response.setStatus("errors were encountered when updating the payment");
            return response;
        
        }
        
    
    }
   
   //Endpoint for getting payment by id
    @Path("/getpayment/{paymentId}")
    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
      public CustomeResponseMessage getPaymentById(@PathParam("paymentId") int paymentId){
        CustomeResponseMessage response=new CustomeResponseMessage();
        response.setData(paymentBean.getPaymentById(paymentId).toString());
        response.setStatus("payment fetched successfully");
        return response;
           
        
        }
      
    //Endpoint for getting all payment
    @Path("/getpayment")
    @POST
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
      public CustomeResponseMessage getPaymentAllPayment(){
        CustomeResponseMessage response=new CustomeResponseMessage();
        response.setData(paymentBean.getAllPayments().toString());
        response.setStatus("payments fetched successfully");
        return response;
           
        
        }


    
    
    
}
