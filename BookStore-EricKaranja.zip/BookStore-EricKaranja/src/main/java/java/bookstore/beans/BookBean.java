/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.beans;

import java.bookstore.interfaces.BookI;
import java.bookstore.models.Book;
import java.util.List;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 *
 * @author karanjaeric
 */
@Stateless
@DeclareRoles({"ADMINISTRATOR,AUTHOR,PUBLISHER,CUSTOMER"})
public class BookBean implements BookI {
    
    @PersistenceContext
    EntityManager em;

    @Override
    //This method adds a book to the system
    @RolesAllowed({"ADMINISTRATOR","PUBLISHER"})
    public boolean add(Book book) {
        try{
            em.persist(book);
            return true;
        
        }catch(PersistenceException pex){
            return false;
        
        }
    }

    @Override
    //This method updates a book
    @RolesAllowed("ADMINISTRATOR")
    public boolean update(Book book) {
      try{
        Book newbook=em.find(Book.class, book.getId());
        em.merge(book);
        return true;
      }catch(PersistenceException pex){
          return false;
      }
    }

    //This method deletes a book from the system
    @Override
    @RolesAllowed("ADMINISTRATOR")
    public boolean delete(Book book) {
       try{
        Book newbook=em.find(Book.class, book.getId());
        em.remove(book);
        return true;
      }catch(PersistenceException pex){
          return false;
      }
        
    }

    @Override
    public List<Book> getAllBoooks() {
        return em.createNamedQuery("getAllBooks").getResultList();
    }


  
}
