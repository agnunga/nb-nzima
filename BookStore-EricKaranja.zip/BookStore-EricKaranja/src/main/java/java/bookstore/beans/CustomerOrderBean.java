/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.beans;

import java.bookstore.interfaces.CustomerOrderI;
import java.bookstore.models.CustomerOrder;
import java.bookstore.models.OrderStatus;
import java.util.List;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 *
 * @author karanjaeric
 */
@Stateless
//This class implements all the methods for adding,cancelling and approving a customer order
@DeclareRoles({"ADMINISTRATOR","CUSTOMER","AUTHOR","PUBLISHER"})
public class CustomerOrderBean implements CustomerOrderI {
    @PersistenceContext
    EntityManager em;

    //This method adds a customer order in the system
    @Override
    @RolesAllowed("CUSTOMER")
    public boolean add(CustomerOrder order) {
       try{
            em.persist(order);
            return true;
        
        }catch(PersistenceException pex){
            return false;
        
        }
    }

    //This method cancells an order
    @Override
    @RolesAllowed({"ADMINISTRATOR","CUSTOMER"})
    public boolean cancel(CustomerOrder order) {
       return editCustomerOrder(order,OrderStatus.CANCELLED);
        
    }
    //This method approves a customer order
    @Override
    @RolesAllowed("ADMINISTRATOR")
    public boolean approve(CustomerOrder order) {
        return editCustomerOrder(order,OrderStatus.COMPLETED);
      
    }

    //This method returns a single customer order
    @Override
    @RolesAllowed({"ADMINISTRATOR","CUSTOMER"})
    public CustomerOrder getOrderById(CustomerOrder order) {
        return em.find(CustomerOrder.class, order.getOrderId());
    }
    
    //This method returns a list of all orders
    @Override
    @RolesAllowed({"ADMINISTRATOR","CUSTOMER"})
    public List<CustomerOrder> getAllOrders(CustomerOrder order) {
        return em.createNamedQuery("getCustomerOrders").getResultList();
    }
    //This method edits the status of an order
    @RolesAllowed({"ADMINISTRATOR"})
    public boolean editCustomerOrder(CustomerOrder order,OrderStatus status){
       try{
        CustomerOrder  orderToEdit=getOrderById(order);
        orderToEdit.setOrderStatus(status);
        em.merge(orderToEdit);
        return true;
      }catch(PersistenceException pex){
          return false;
      }
    
    
    }

  
}
