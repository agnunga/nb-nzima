/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.beans;

import java.bookstore.interfaces.PaymentI;
import java.bookstore.models.Payment;
import java.bookstore.models.PaymentStatus;
import java.util.List;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 *
 * @author karanjaeric
 */
@Stateless
@DeclareRoles({"ADMINISTRATOR,AUTHOR,PUBLISHER,CUSTOMER"})
public class PaymentBean implements PaymentI{
    @PersistenceContext
    private EntityManager em;

    @Override
    public boolean makePayment(Payment payment) {
        try{
            em.persist(payment);
            return true;
        }catch(PersistenceException pex){
            return false;
        
        }
    }

    @Override
     @RolesAllowed("CUSTOMER")
    public boolean updatePayment(Payment payment, PaymentStatus paymentStatus) {
        try{
           Payment updatedPayment=editPayment(payment,paymentStatus);
           em.merge(updatedPayment);
          
        return true;
        }catch(PersistenceException pex){
            return false;
        }
     
     
    }

    @Override
     @RolesAllowed("ADMINISTRATOR")
    public Payment getPaymentById(int paymentId) {
        return em.find(Payment.class, paymentId);
    }

    @Override
     @RolesAllowed("ADMINISTRATOR")
    public List<Payment> getAllPayments() {
        return em.createNamedQuery("getAllPayments").getResultList();
    }

    @Override
     @RolesAllowed("ADMINISTRATOR")
    public Payment editPayment(Payment payment, PaymentStatus status) {
        Payment paymentToEdit=getPaymentById(payment.getPaymentId());
        paymentToEdit.setPaymentStatus(status);
        return paymentToEdit;
        
    }



}
