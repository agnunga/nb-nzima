/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.beans;

import java.bookstore.interfaces.ShipmentI;
import java.bookstore.models.Location;
import java.bookstore.models.Shipment;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 *
 * @author karanjaeric
 */
//Shipment implement bean
@Stateless
public class ShipmentBean implements ShipmentI {
    //inject persistence
    @PersistenceContext 
    EntityManager em;
    
    //This method dispatches an order
    @Override
    public boolean dispatch() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }




    @Override
    //This method edits shipment details 
    public boolean editShipment(Shipment shipment) {
        try{
        Shipment newShipment=getShipmentById(shipment.getShipmentId());
        em.merge(shipment);
        return true;
        
        }catch(PersistenceException pex){
            return true;
        
        }

        
    }

    @Override
    //This method adds a shipment in the system
    public boolean add(Shipment shipment) {
        try{
            em.persist(shipment);
            return true;
        
        }catch(PersistenceException pex){
            return false;
            
        }
    }

    @Override
    //This method achieves shipment tracking
    public Location trackShipmentLocation(Shipment shipment) {
        return shipment.getLocation();
        
    }
    public Shipment getShipmentById(int id){
        return em.find(Shipment.class, id);
    
    }

    
}
