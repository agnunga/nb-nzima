/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.beans;

import java.bookstore.events.RegistrationEvent;
import java.bookstore.interfaces.UserI;
import java.bookstore.models.User;
import java.util.Queue;
import javax.annotation.Resource;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 *
 * @author karanjaeric
 */
//Bean implementation of the UserI interface
@Stateless
@DeclareRoles({"ADMINISTRATOR,AUTHOR,PUBLISHER,CUSTOMER"})
public class UserBean implements UserI {
    @Inject
    JMSContext context;

    @Resource(lookup = "java:/myJmsTest/MyQueue")
    private Queue queue;
    //Inject persistence
    @PersistenceContext
    private EntityManager em;
    
    //inject event  
    @Inject
    Event<RegistrationEvent> registrationEvent;

    @Override
    //This method registers a user.
    @RolesAllowed({"ADMINISTRATOR,AUTHOR,PUBLISHER,CUSTOMER"})
    public User add(User user) {
        try{
            em.persist(user);
            registrationEvent.fire((RegistrationEvent) registrationEvent);
            return user;
        
        }catch(PersistenceException pex){
            return null;
        
        }
    }

    //This method updates a user
    @Override
    @RolesAllowed({"ADMINISTRATOR,AUTHOR,PUBLISHER,CUSTOMER"})
    public User update(User user) {
        try{
        
        User newUser=retrieve(user.getId());
        em.persist(newUser);
        return newUser;
        }catch(PersistenceException pex){
            return null;
        
        }
    }

       //This method deletes a user from the system
    @Override
    @RolesAllowed("ADMINISTRATOR")
    public boolean delete(long id) {
        try{
           em.remove(retrieve(id));
           return true;
            
        
        }catch(PersistenceException pex){
            return false;
        
        }
        
    }

    //This method retrieves a user by id
    @Override
    @RolesAllowed("ADMINISTRATOR")
    public User retrieve(long id) {
        return em.find(User.class, id);
    }

    //This method authenticates a user with the provided credentials
    @Override
    @RolesAllowed({"ADMINISTRATOR,AUTHOR,PUBLISHER,CUSTOMER"})
    public User authenticateUser(String username, String password) {
        return (User) em.createNamedQuery("User.login").setParameter("username",username).setParameter("password",password).getSingleResult();
    }
    
    //Method for sending a text message through JMS
    public void sendSms(String phoneNumber){
          context.createProducer().setTimeToLive(1000).send((Destination) queue, phoneNumber);
    
    }
    
    //method for sending email message through JMS   
    public void sendEmail(String email){
          context.createProducer().setTimeToLive(1000).send((Destination) queue, email);
    
    }

    @Override
    public User retriveAllUsers() {
        return (User) em.createNamedQuery("getAllUsers").getResultList();
    }
    

}
