/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.eventsListener;

import java.bookstore.events.RegistrationEvent;
import javax.ejb.EJB;
import javax.enterprise.event.Observes;
import javax.mail.MessagingException;

/**
 *
 * @author karanjaeric
 */
//This listener is responsible for handling all events in the system
public class EventsListener {
        @EJB
        RegistrationEvent regEvent;
    public void registrationListener(@Observes RegistrationEvent registrationEvent) throws MessagingException{
    
        String emailMessage="new customer has been added";
        regEvent.sendEmail("muthike789@gmail.com", "admin@gmail.com", "karanjaeric","karanjaeric","new Customer", emailMessage);
    
    }
    
    
}
