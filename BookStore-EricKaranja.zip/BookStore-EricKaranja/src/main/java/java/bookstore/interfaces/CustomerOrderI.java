/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.interfaces;

import java.bookstore.models.CustomerOrder;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author karanjaeric
 */
//This interface defines all the methods to be implemented by classes of type CustomerOrderI
@Local
public interface CustomerOrderI {
    boolean add(CustomerOrder order);
    boolean cancel(CustomerOrder order);
    boolean approve(CustomerOrder order);
    CustomerOrder getOrderById(CustomerOrder order);
    List<CustomerOrder> getAllOrders(CustomerOrder order);
    
    
    
}
