/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.interfaces;

import java.bookstore.models.PaymentStatus;
import java.bookstore.models.Payment;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author karanjaeric
 */
@Local
public interface PaymentI {
    boolean makePayment(Payment payment);
    boolean updatePayment(Payment payment, PaymentStatus paymentStatus);  
    Payment getPaymentById(int paymentId);
    List<Payment> getAllPayments();
    Payment editPayment(Payment payment,PaymentStatus status);
}
