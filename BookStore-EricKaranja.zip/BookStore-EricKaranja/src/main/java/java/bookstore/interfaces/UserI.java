/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.interfaces;

import java.bookstore.models.User;
import javax.ejb.Local;

/**
 *
 * @author karanjaeric
 */
@Local
public interface UserI {
   
    public User add(User user) ;
    public User update(User user) ;
    public boolean delete(long id) ;
    public User retrieve(long id) ;
    public User authenticateUser(String username,String password);
    public User retriveAllUsers();
    
}
