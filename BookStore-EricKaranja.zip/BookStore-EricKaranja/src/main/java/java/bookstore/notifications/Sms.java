/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java.bookstore.notifications;

import com.bookstore.gateways.AfricasTalkingGateway;
import java.bookstore.qualifiers.Notification;
import static java.bookstore.qualifiers.Notification.Type.SMS;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author karanjaeric
 */
@Notification(SMS)
public class Sms {
    
    public boolean sendSmsMessage(String phoneNumber,String message){
    
                // Specify your login credentials
            String username = "karanjaeric";
            String apiKey   = "ec2e73789eebc33c21b31581298dd53f850b27a7f07a90dc4d9400e903c2a726";
            String recipients = phoneNumber;
            String message1 = message;
            AfricasTalkingGateway gateway  = new AfricasTalkingGateway(username, apiKey);

        try {
            JSONArray results = gateway.sendMessage(recipients, message);
            
            for( int i = 0; i < results.length(); ++i ) {
                  JSONObject result = results.getJSONObject(i);
                  System.out.print(result.getString("status") + ","); // status is either "Success" or "error message"
                  System.out.print(result.getString("number") + ",");
                  System.out.print(result.getString("messageId") + ",");
                  System.out.println(result.getString("cost"));
                  return true;
        }
       }
       
       catch (Exception e) {
        System.out.println("Encountered an error while sending " + e.getMessage());
        }
        return false;
    
   }
    //overloaded method to send sms to many members
    public boolean sendSmsMessage(List<String> phoneNumbers, String message){
                        // Specify your login credentials
            String username = "karanjaeric";
            String apiKey   = "ec2e73789eebc33c21b31581298dd53f850b27a7f07a90dc4d9400e903c2a726";
            String recipients ="";
            //capture all phone numbers
            for(String phoneNumber:phoneNumbers){
                recipients+=phoneNumber+",";
            
            }
            
            String message1 = message;
            AfricasTalkingGateway gateway  = new AfricasTalkingGateway(username, apiKey);

        try {
            JSONArray results = gateway.sendMessage(recipients, message);
            
            for( int i = 0; i < results.length(); ++i ) {
                  JSONObject result = results.getJSONObject(i);
                  System.out.print(result.getString("status") + ","); // status is either "Success" or "error message"
                  System.out.print(result.getString("number") + ",");
                  System.out.print(result.getString("messageId") + ",");
                  System.out.println(result.getString("cost"));
                  return true;
        }
       }
       
       catch (Exception e) {
        System.out.println("Encountered an error while sending " + e.getMessage());
        }
        return false;
    
    
    }
     
}
