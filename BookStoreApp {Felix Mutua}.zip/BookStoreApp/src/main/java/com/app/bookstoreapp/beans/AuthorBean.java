/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.AuthorBeanI;
import com.app.bookstoreapp.dao.AuthorDao;
import com.app.bookstoreapp.models.Author;
import com.app.bookstoreapp.utils.BookStoreDaoFactory;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.app.bookstoreapp.interceptors.CatchMyException;

/**
 *
 * @author FelixMutua
 */
@Stateless
@CatchMyException
public class AuthorBean implements AuthorBeanI{
    
    @PersistenceContext(name = "BookStorePU")
    EntityManager entityManager;
            

    @Override
    public Author create(Author author) {
     return (Author) dao().save(author);
    
    }

    @Override
    public Author findById(Long id) {
     return (Author) dao().findById(id);
    }

    @Override
    public Author update(Author author) {
    return (Author) dao().merge(author);
    }

    @Override
    public boolean delete(Author author) {
     return dao().remove(author);
    }
     
    AuthorDao dao(){
        AuthorDao ad = (AuthorDao) new BookStoreDaoFactory("AD").getDao(entityManager);
        return ad;
    }

    @Override
    public List<Author> getAll() {
    return  dao().findAll();
    }
}
