/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.BookBeanI;
import com.app.bookstoreapp.dao.BookDao;
import com.app.bookstoreapp.models.Book;
import com.app.bookstoreapp.utils.BookStoreDaoFactory;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.app.bookstoreapp.qualifiers.EightDigitsIsbn;
import com.app.bookstoreapp.qualifiers.NumberGenerator;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class BookBean implements BookBeanI {

    @Inject
    @EightDigitsIsbn
    private NumberGenerator generator;

    @PersistenceContext(name = "BookStorePU ")
    EntityManager entityManager;

    @Override
    public Book create(Book book) {

        book.setISBN(generator.generateNumber());
        return (Book) dao().save(book);
    }

    @Override
    public Book findById(Long id) {
        return (Book) dao().findById(id);

    }

    @Override
    public Book update(Book book) {
        return (Book) dao().merge(book);
    }

    @Override
    public boolean delete(Book book) {
        return dao().remove(book);
    }

    BookDao dao() {
        BookDao bd = (BookDao) new BookStoreDaoFactory("BD").getDao(entityManager);
        return bd;
    }

    @Override
    public List<Book> getAll() {
        return dao().findAll();
    }

}
