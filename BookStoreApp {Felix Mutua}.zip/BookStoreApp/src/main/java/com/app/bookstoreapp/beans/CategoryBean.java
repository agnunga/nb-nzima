/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.dao.CategoryDao;
import com.app.bookstoreapp.models.Category;
import com.app.bookstoreapp.utils.BookStoreDaoFactory;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.app.bookstoreapp.beansI.CategoryBeanI;
import java.util.List;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class CategoryBean implements CategoryBeanI{

    
    @PersistenceContext(name = "BookStorePU")
    EntityManager entityManager;
   
    @Override
    public Category create(Category catalog) {
      return (Category) dao().save(catalog);
    }

    @Override
    public Category findById(Long id) {
    return (Category) dao().findById(id);
    }

    @Override
    public Category update(Category catalog) {
     return (Category) dao().merge(catalog);
    }

    @Override
    public boolean delete(Category catalog) {
    return dao().remove(catalog);
    }
    
    CategoryDao dao(){
        CategoryDao cd = (CategoryDao) new BookStoreDaoFactory("CD").getDao(entityManager);
        return cd;
    }

    @Override
    public List<Category> getAll() {
     return dao().findAll();
    }

    @Override
    public Category deleteById(long id) {
        return dao().deleteById(id);
    }
    
}
