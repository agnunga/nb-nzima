/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.CustomerOrderI;
import com.app.bookstoreapp.dao.CustomerOrderDao;
import com.app.bookstoreapp.models.CustomerOrder;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class CustomerOrderBean implements CustomerOrderI {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public CustomerOrder addOrder(CustomerOrder customerOrder) {
        CustomerOrderDao cod = new CustomerOrderDao(entityManager);
        return cod.save(customerOrder);
    }

    @Override
    public boolean removeOrder(CustomerOrder customerOrder) {
        CustomerOrderDao cod = new CustomerOrderDao(entityManager);
        return cod.remove(customerOrder);
    }

    @Override
    public CustomerOrder findCustomerOrder(long id) {
        CustomerOrderDao cod = new CustomerOrderDao(entityManager);
        return cod.findById(id);
    
    }

}
