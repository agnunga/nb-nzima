/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.CustomerOrderI;
import com.app.bookstoreapp.beansI.PaymentBeanI;
import com.app.bookstoreapp.beansI.UserBeanI;
import com.app.bookstoreapp.dao.PaymentDao;
import com.app.bookstoreapp.models.CustomerOrder;
import com.app.bookstoreapp.models.Invoice;
import com.app.bookstoreapp.models.Payment;
import com.app.bookstoreapp.models.User;
import java.util.Queue;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class PaymentBean implements PaymentBeanI {

    @EJB
    UserBeanI ub;
    @EJB
    CustomerOrderI cobi;

    @Inject
    JMSContext context;

    @Resource(lookup = "java:/myJmsTest/MyQueue")
    private Queue queue;
    @PersistenceContext
    EntityManager em;
    
    @Override
     public Payment makePayment(Payment payment,CustomerOrder co,long id) {
        co = cobi.findCustomerOrder(id);
        PaymentDao pd = new PaymentDao(em);
        return pd.save(new Payment(co));
       
        
    
    }
    @Override
    public void confirmation(long id) {
        User user = ub.findById(id);
        Invoice invoice = new Invoice(user.getAddress(), user.getEmail(), user.getFirstName(), user.getPhone());
        invoice.setUser(user);
        context.createProducer().setTimeToLive(1000).send((Destination) queue, invoice);
        Logger logger = LoggerFactory.getLogger(Invoice.class);
        logger.info("added to queue");

        logger.info("You will Receive a Notification Email");

    }

    
}
