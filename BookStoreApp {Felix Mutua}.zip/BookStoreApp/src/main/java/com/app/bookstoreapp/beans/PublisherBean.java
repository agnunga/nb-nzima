/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.PublisherBeanI;
import com.app.bookstoreapp.dao.BookStoreGenericDao;
import com.app.bookstoreapp.dao.PublisherDao;
import com.app.bookstoreapp.models.Publisher;
import com.app.bookstoreapp.utils.BookStoreDaoFactory;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class PublisherBean implements PublisherBeanI {

    @PersistenceContext(name = "BookStorePU")
    EntityManager entityManager;

    @Override
    public Publisher create(Publisher publisher) {
        return (Publisher) dao().save(publisher);

    }

    @Override
    public Publisher findById(Long id) {
     return (Publisher) dao().findById(id);
    }

    @Override
    public Publisher update(Publisher publisher) {
      return (Publisher) dao().merge(publisher);
      }

    @Override
    public boolean delete(Publisher publisher) {
     return dao().remove(publisher);
    }

    PublisherDao dao() {
        PublisherDao pd = (PublisherDao) new BookStoreDaoFactory("PD").getDao(entityManager);
        return pd;
    }

    @Override
    public List<Publisher> getAll() {
      return dao().findAll();
    }
}
