/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.ShipmentBeanI;
import com.app.bookstoreapp.dao.ShipmentDao;
import com.app.bookstoreapp.models.Shipment;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class ShipmentBean implements ShipmentBeanI{

    @PersistenceContext
    EntityManager entityManager;
    ShipmentDao dao = new ShipmentDao(entityManager);
    @Override
    public Shipment addShipment(Shipment shipment) {
        
       return dao.save(shipment);
     
    }

    @Override
    public boolean removeShipment(Shipment s) {
    return dao.remove(s);
    }
    
}
