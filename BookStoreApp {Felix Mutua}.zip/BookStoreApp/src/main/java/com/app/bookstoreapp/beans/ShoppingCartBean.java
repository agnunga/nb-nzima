/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.ShoppingCartBeanI;
import com.app.bookstoreapp.dao.ShoppingCartDao;
import com.app.bookstoreapp.models.Book;
import com.app.bookstoreapp.models.ShoppingCart;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class ShoppingCartBean implements ShoppingCartBeanI {

    @PersistenceContext
    EntityManager em;
    ShoppingCartDao cartDao = new ShoppingCartDao(em);
    int numberOfBooksInCart;

    @Override
    public boolean addBookToCart(Book book) {

        return cartDao.save(new ShoppingCart(book, 1)) != null;

    }

    @Override
    public boolean removeBookFromCart(Book book) {
        return cartDao.remove(new ShoppingCart(book, -1));

    }

    @Override
    public int getNumberOfBooksInCart() {
        List<ShoppingCart> items = allCartItems();
        numberOfBooksInCart = 0;
        for (ShoppingCart item : items) {
            numberOfBooksInCart += item.getQuantity();

        }
        return numberOfBooksInCart;
    }

    @Override
    public double calculateTotal() {
        double totalPrice=0;
         List<ShoppingCart> items = allCartItems();
         for (ShoppingCart item : items) {
            Book book = item.getBook();
            totalPrice +=(item.getQuantity()*book.getPrice());
        }
         return totalPrice;        
     }

    @Override
    public List<ShoppingCart> allCartItems() {
        return cartDao.findAll();
    }

}
