/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beans;

import com.app.bookstoreapp.beansI.UserBeanI;
import com.app.bookstoreapp.dao.UserDao;
import com.app.bookstoreapp.models.User;
import com.app.bookstoreapp.utils.BookStoreDaoFactory;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author FelixMutua
 */
@Stateless
public class UserBean implements UserBeanI {

    @PersistenceContext(name = "BookStorePU")
    public EntityManager entityManager;

    @Override
    public User create(User user) {
        return (User) dao().save(user);
    }

    @Override
    public User findById(Long id) {
        return (User) dao().findById(id);
    }

    @Override
    public User update(User user) {
        return (User) dao().merge(user);
    }

    @Override
    public boolean delete(User user) {
        return dao().remove(user);

    }

    UserDao dao() {
        UserDao ud = (UserDao) new BookStoreDaoFactory("UD").getDao(entityManager);
        return ud;
    }

    @Override
    public User login(String username, String password) {
        return dao().doLogin(username, password);
    }

    @Override
    public List<User> getAll() {
        return dao().findAll();
    }

}
