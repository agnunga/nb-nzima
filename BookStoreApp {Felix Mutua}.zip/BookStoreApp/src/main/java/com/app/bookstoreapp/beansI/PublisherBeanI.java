/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beansI;

import com.app.bookstoreapp.models.Publisher;
import java.util.List;

/**
 *
 * @author FelixMutua
 */
public interface PublisherBeanI {
     Publisher create(Publisher publisher);    
    Publisher findById(Long id);
    Publisher update(Publisher publisher);
    boolean delete(Publisher publisher); 
    List<Publisher> getAll();
}
