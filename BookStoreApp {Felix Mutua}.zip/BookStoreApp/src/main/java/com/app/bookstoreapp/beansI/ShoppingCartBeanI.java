/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beansI;

import com.app.bookstoreapp.models.Book;
import com.app.bookstoreapp.models.ShoppingCart;
import java.util.List;

/**
 *
 * @author FelixMutua
 */
public interface ShoppingCartBeanI {
     boolean addBookToCart( Book book);
     boolean removeBookFromCart(Book book);
      List<ShoppingCart> allCartItems();
     int getNumberOfBooksInCart();
     double calculateTotal();
     
     
     
}
