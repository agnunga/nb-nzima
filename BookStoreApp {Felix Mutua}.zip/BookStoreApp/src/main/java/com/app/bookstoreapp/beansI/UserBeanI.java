/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.beansI;

import com.app.bookstoreapp.models.User;
import java.util.List;



/**
 *
 * @author FelixMutua
 */
public interface UserBeanI {
    User create(User user); 
    User login (String username, String password);
    User findById(Long id);
    User update(User user);
    boolean delete(User user);
    List<User> getAll();
    
    
}
