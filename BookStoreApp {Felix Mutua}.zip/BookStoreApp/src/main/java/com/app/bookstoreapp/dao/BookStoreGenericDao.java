/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.dao;

import com.app.bookstoreapp.daoI.BookStoreGenericDaoI;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author FelixMutua
 * @param <T>
 * @param <PK>
 */
public class BookStoreGenericDao<T,PK extends Serializable> implements BookStoreGenericDaoI<T, PK> {
    private Class<T> entityClass;
    private EntityManager entityManager;
    private Logger logger;
    
    public BookStoreGenericDao(Class<T> entityClass, EntityManager entityManager) {
        this.logger = LoggerFactory.getLogger(entityClass);
        this.entityClass = entityClass;
        this.entityManager = entityManager;
    }
     @Override
    public T save(T t) {
        try {
             logger.info("Preparing to Persist Object");
            this.entityManager.persist(t);
             logger.info("Object Persisted");
            return t;
        } catch (PersistenceException pe) {
             logger.error(pe.getMessage());
            return null;
        }
    }

    @Override
    public T findById(PK id) {
        try {
            return this.entityManager.find(entityClass, id);
        } catch (PersistenceException pe) {
            logger.error(pe.getMessage());
              return null;
        }
    }

    @Override
    public T merge(T t) {
         try {
            return this.entityManager.merge(t);
        }  catch (PersistenceException pe) {
            logger.error(pe.getMessage());
             return null;
        }
    }

    @Override
    public List<T> findAll() {
         return this.entityManager.createQuery("SELECT t FROM " + entityClass.getSimpleName() + " t").getResultList();
    }
    

    @Override
    public boolean remove(T t) {
         try {
            t = this.entityManager.merge(t);
            this.entityManager.remove(t);
            return true;
        }  catch (PersistenceException pe) {
            logger.error(pe.getMessage());
            return false;
        }
    }

    @Override
     public T doLogin (String username, String password){
       return (T) this.entityManager.createNamedQuery("User.LOGIN").setParameter("username",username).setParameter("password",password).getSingleResult();
        
        
    }

    @Override
    public T deleteById(PK id) {
        return (T) this.entityManager.createNamedQuery("Category.DeleteByID").setParameter("id", id).getSingleResult();
    
            
    }
   
    
}
