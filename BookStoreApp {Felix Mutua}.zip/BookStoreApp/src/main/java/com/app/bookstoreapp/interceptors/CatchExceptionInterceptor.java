/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.interceptors;

import com.app.bookstoreapp.beansI.UserBeanI;
import javax.ejb.EJB;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 

/**
 *
 * @author FelixMutua
 */
@CatchMyException
@Interceptor
public class CatchExceptionInterceptor {
   
   
    private Logger logger =LoggerFactory.getLogger(Object.class);
   @AroundInvoke 
   public Object intercept(InvocationContext ic) throws Exception {
        try {
            return ic.proceed();
        } catch (Exception e) {
            e.getMessage();
            logger.error("Exception");
            return null;
        }
    }
}
    
    
    

