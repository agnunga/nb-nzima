/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.models;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author FelixMutua
 */
@Entity
public class Payment implements Serializable {

     @Id
     @GeneratedValue
    private long paymentId;
    @NotNull
    private PaymentType type;

    public Payment() {
    }
    

    public Payment(CustomerOrder co) {
     }
    
 
    
    //Getters and Setters

    public long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(long paymentId) {
        this.paymentId = paymentId;
    }

    public PaymentType getType() {
        return type;
    }

    public void setType(PaymentType type) {
        this.type = type;
    }
    
   
    
    

}