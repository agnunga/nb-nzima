/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.qualifiers;

import javax.inject.Inject;

/**
 *
 * @author FelixMutua
 */
@EightDigitsIsbn
public class IsbnGenerator implements NumberGenerator {
    @Inject
    @EightDigitsIsbn
    private String prefix;

    @Inject
    @EightDigitsIsbn
    
    private int postfix;

     
    @Override
     public String generateNumber() {
        return prefix + Math.random() / 1000 + postfix;
    }
}
