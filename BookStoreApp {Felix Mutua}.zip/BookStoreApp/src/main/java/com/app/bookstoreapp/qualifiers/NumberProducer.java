/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.qualifiers;

import javax.enterprise.inject.Produces;

/**
 *
 * @author FelixMutua
 */
public class NumberProducer {
  
    @Produces 
    @EightDigitsIsbn
    private String prefix2 = "8-";

    @Produces 
    @EightDigitsIsbn
    private int postfix2 = 4;

}
