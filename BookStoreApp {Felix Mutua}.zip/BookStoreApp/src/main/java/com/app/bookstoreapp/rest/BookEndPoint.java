/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.rest;

import com.app.bookstoreapp.beansI.BookBeanI;
import com.app.bookstoreapp.models.Book;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author FelixMutua
 */
@Path("/books")
public class BookEndPoint {

    @EJB
    BookBeanI bbi;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Book entity) {
        return Response.status(200).entity(bbi.create(entity)).build();
    }
    
     @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") long id) {
       
        return Response.status(200).entity(bbi.findById(id)).build();
    }
    
     @GET
    @Produces(MediaType.APPLICATION_JSON)
     @Path("/listAll")
    public Response listAll() {
     return Response.status(200).entity(bbi.getAll()).build();
    }

}
