/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.rest;

import com.app.bookstoreapp.beansI.PaymentBeanI;
import com.app.bookstoreapp.models.Book;
import com.app.bookstoreapp.models.CustomerOrder;
import com.app.bookstoreapp.models.Payment;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author FelixMutua
 */
@Path("/pay")
public class PaymentEndPoint {
    
    @EJB
    PaymentBeanI pbi;
    
    @POST
    @Path("/makePayment")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response makePayment(Payment p, CustomerOrder co,long id) {
        return Response.status(200).entity(pbi.makePayment(p, co, id)).build();
    }
}
