/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.servlet;

import com.app.bookstoreapp.beansI.BookBeanI;
import com.app.bookstoreapp.beansI.ShoppingCartBeanI;
import com.app.bookstoreapp.models.Book;
import com.app.bookstoreapp.models.ShoppingCart;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author FelixMutua
 */
@WebServlet(name = "AddToCart", urlPatterns = {"/AddToCart"})
public class AddToCart extends HttpServlet {

    @EJB
    BookBeanI bbi;
    @EJB
    ShoppingCartBeanI scbi;
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("Books", bbi.getAll());
        if (request.getParameter("id") != null) {
            request.getAttribute("Books");
            RequestDispatcher dispatcher = request.getRequestDispatcher("customer/productpage.jsp");
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        request.setAttribute("Books", bbi);
        Book book = bbi.findById(Long.parseLong(request.getParameter("id")));
        if(scbi.addBookToCart(book)){
            out.print("Success adding to cart");
        }
          
         

    }
}
