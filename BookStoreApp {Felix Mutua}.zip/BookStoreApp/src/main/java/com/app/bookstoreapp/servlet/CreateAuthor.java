/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.servlet;

import com.app.bookstoreapp.beansI.AuthorBeanI;
import com.app.bookstoreapp.models.Author;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author FelixMutua
 */
@WebServlet(name = "CreateAuthor", urlPatterns = {"/CreateAuthor"})
public class CreateAuthor extends HttpServlet {
 
    
     @EJB
     AuthorBeanI abi;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("admin/author/create.jsp");
        dispatcher.forward(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            Author author = new Author();
            
            PrintWriter out = response.getWriter();
            
            author.setFirstName(request.getParameter("fname"));
            author.setLastName(request.getParameter("lname"));
            author.setBio(request.getParameter("bio"));
            
            DateFormat df = new SimpleDateFormat("mm/dd/yyyy");
            Date dob;
         try {
             dob = df.parse(request.getParameter("dob"));
             author.setDateOfBirth(dob);
         } catch (ParseException ex) {
             Logger.getLogger(CreateAuthor.class.getName()).log(Level.SEVERE, null, ex);
         }
            
            if(abi.create(author)!=null){
                out.print("Success Creating Author");
            }
         
         
        
        
       
        
    }
 
}
