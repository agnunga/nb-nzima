/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.servlet;

import com.app.bookstoreapp.beansI.UserBeanI;
import com.app.bookstoreapp.interceptors.CatchExceptionInterceptor;
import com.app.bookstoreapp.interceptors.CatchMyException;
import com.app.bookstoreapp.models.User;
import com.app.bookstoreapp.models.UserRole;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author FelixMutua
 */
@WebServlet(name = "LoginUser", urlPatterns = {"/doSignIn"})
public class LoginUser extends HttpServlet {

    @EJB
    UserBeanI ubi;
    
    @CatchMyException
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter printWriter = response.getWriter();
       
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        User authorizedUser = ubi.login(user.getUsername(), user.getPassword());
        if (authorizedUser != null) {
            HttpSession hs = request.getSession();
            hs.setAttribute("AuthorizedUser", user);

            switch (authorizedUser.getRole()) {
                case ADMIN:
                    response.sendRedirect("adminpanel.jsp");
                    break;
                case CUSTOMER:
                    response.sendRedirect("customerpanel.jsp");
                    break;
                default:
                    printWriter.print("<h1>Cannot Login User</h1>");
                    break;
            }

        } else {
            printWriter.print("<h1>Cannot Login User</h1>");
        }

    }
}
