/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.servlet;

import com.app.bookstoreapp.beansI.UserBeanI;
import com.app.bookstoreapp.models.User;
import com.app.bookstoreapp.models.UserRole;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author FelixMutua
 */
@WebServlet(name = "RegisterUser", urlPatterns = {"/doSignUp"})
public class RegisterUser extends HttpServlet {
     
    @EJB
    UserBeanI ubi;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("signup.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          PrintWriter out = response.getWriter();
        User user = new User();
        user.setFirstName(request.getParameter("firstname"));
        user.setLastName(request.getParameter("lastname"));
        user.setUsername(request.getParameter("username"));
        user.setEmail(request.getParameter("email"));
        user.setPassword(request.getParameter("password"));
        user.setPhone(request.getParameter("phone"));
        user.setAddress(request.getParameter("address"));
        UserRole role = Enum.valueOf(UserRole.class, request.getParameter("user_role"));
        user.setRole(role);
        
        if(ubi.create(user)!=null){
            out.print("Welcome " + role + " " + user.getFirstName() );
        }
    }

}
