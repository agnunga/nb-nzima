/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.bookstoreapp.utils;

import com.app.bookstoreapp.dao.AuthorDao;
import com.app.bookstoreapp.dao.BookDao;
import com.app.bookstoreapp.dao.BookStoreGenericDao;
import com.app.bookstoreapp.dao.CategoryDao;
import com.app.bookstoreapp.dao.PublisherDao;
import com.app.bookstoreapp.dao.UserDao;
import javax.persistence.EntityManager;

/**
 *
 * @author FelixMutua
 */
public class BookStoreDaoFactory {

    String type;

    public BookStoreDaoFactory(String type) {
        this.type = type;
    }

    public BookStoreGenericDao getDao(EntityManager manager) {
        if (this.type.equalsIgnoreCase("UD")) {
            return new UserDao(manager);

        } else if (this.type.equalsIgnoreCase("BD")) {
            return new BookDao(manager);
        } else if (this.type.equalsIgnoreCase("CD")) {
            return new CategoryDao(manager);

        } else if (this.type.equalsIgnoreCase("AD")) {
            return new AuthorDao(manager);

        } else if (this.type.equalsIgnoreCase("PD")) {
            return new PublisherDao(manager);
        } else {
            return null;
        }
    }

}
